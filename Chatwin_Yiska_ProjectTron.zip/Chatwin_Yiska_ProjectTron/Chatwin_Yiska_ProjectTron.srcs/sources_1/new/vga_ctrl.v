`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 11/12/2026 03:50:34 PM
// Design Name: 
// Module Name: vga_ctrl
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module vga_ctrl(
    input        clk_pix,       // 25 MHz (25.175 MHz is the exact standard)
    input        clear,
    output reg   V_sync,
    output reg   H_sync,
    output [9:0] H_cnt,
    output [9:0] V_cnt,
    output reg   Vid_on
);
    parameter HPIXELS = 800;    // 96 sync + 48 back porch + 640 visible + 16 front porch
    parameter VLINES  = 525;    // 2 sync + 33 back porch + 480 visible + 10 front porch
    parameter HSP = 96;
    parameter HBP = 144;        // 96 + 48
    parameter HFP = 784;        // 144 + 640
    parameter VSP = 2;
    parameter VBP = 35;         // 2 + 33
    parameter VFP = 515;        // 35 + 480

    reg [9:0] H_count_reg, H_count_next;
    reg [9:0] V_count_reg, V_count_next;

    always @(posedge clk_pix) begin
        if (clear) begin
            H_count_reg <= 10'd0;
            V_count_reg <= 10'd0;
        end else begin
            H_count_reg <= H_count_next;
            V_count_reg <= V_count_next;
        end
    end

    always @(*) begin
        if (H_count_reg == HPIXELS-1) H_count_next = 10'd0;
        else                          H_count_next = H_count_reg + 1;
    end

    wire V_count_en = (H_count_reg == HPIXELS-1);

    always @(*) begin
        V_count_next = V_count_reg;
        if (V_count_en) begin
            if (V_count_reg == VLINES-1) V_count_next = 10'd0;
            else                         V_count_next = V_count_reg + 1;
        end
    end

    assign H_cnt = H_count_reg;
    assign V_cnt = V_count_reg;

    always @(*) H_sync = (H_count_reg < HSP) ? 1'b0 : 1'b1;
    always @(*) V_sync = (V_count_reg < VSP) ? 1'b0 : 1'b1;

    always @(*) begin
        if (H_count_reg >= HBP && H_count_reg < HFP &&
            V_count_reg >= VBP && V_count_reg < VFP)
            Vid_on = 1'b1;
        else
            Vid_on = 1'b0;
    end
endmodule