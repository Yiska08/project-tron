`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 11/12/2026 03:48:18 PM
// Design Name: 
// Module Name: top
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

module top(
    input         clk,              // 100 MHz
    input  [15:0] sw,
    output [3:0]  vgaRed, vgaGreen, vgaBlue,
    output        Hsync, Vsync
);
    wire clk_pix, locked;
    clk_wiz_0 pll(.clk_in1(clk), .clk_out1(clk_pix), .locked(locked));

    wire [9:0] H_cnt, V_cnt;
    wire Vid_on;
    vga_ctrl vga(.clk_pix(clk_pix), .clear(~locked),
                 .V_sync(Vsync), .H_sync(Hsync),
                 .H_cnt(H_cnt), .V_cnt(V_cnt), .Vid_on(Vid_on));

    wire [9:0] x  = H_cnt - 10'd144;     // 0..639
    wire [9:0] y  = V_cnt - 10'd35;      // 0..479
    wire [5:0] cx = x[9:4];              // 0..39
    wire [4:0] cy = y[8:4];              // 0..29

    reg [11:0] rgb;
    always @(*) begin
        case (sw[15:14])
            2'b00:   rgb = sw[11:0];                                        // solid color
            2'b01:   rgb = {{4{x[9]}}, {4{x[8]}}, {4{x[7]}}};               // color bars
            2'b10:   rgb = (cx[0] ^ cy[0]) ? 12'hFFF : 12'h000;             // 16x16 checkerboard
            default: rgb = 12'h000;
        endcase
    end

    assign {vgaRed, vgaGreen, vgaBlue} = Vid_on ? rgb : 12'h000;
endmodule